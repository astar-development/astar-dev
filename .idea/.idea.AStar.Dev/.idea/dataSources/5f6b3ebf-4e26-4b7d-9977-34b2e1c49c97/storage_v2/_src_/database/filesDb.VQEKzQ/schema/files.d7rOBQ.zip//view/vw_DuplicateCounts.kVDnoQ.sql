CREATE VIEW [files].[vw_DuplicateCounts]
   AS
    SELECT COUNT(*) AS Instances,
          [Height]
          ,[Width]
          ,[FileSize]
    FROM
        FilesDb.files.FileDetail AS FD
    INNER JOIN [files].[FileAccessDetail] as FAD ON FAD.Id = FD.FileAccessDetailId
    WHERE HardDeleted = 0
    GROUP BY
        FileSize,
        Height,
        Width
    HAVING
      COUNT(*) > 1;
go

