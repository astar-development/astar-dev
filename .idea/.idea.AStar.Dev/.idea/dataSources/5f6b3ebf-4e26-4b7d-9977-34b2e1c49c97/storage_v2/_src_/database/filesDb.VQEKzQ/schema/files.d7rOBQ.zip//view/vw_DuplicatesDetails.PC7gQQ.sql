CREATE VIEW [files].[vw_DuplicatesDetails]
   AS
    SELECT FD.[Id]
      ,[FileAccessDetailId]
      ,[FileName]
      ,[DirectoryName]
      ,FD.[Height]
      ,FD.[Width]
      ,FD.[FileSize]
      ,[FileHandle]
      ,[IsImage]
      , Dups.Instances
      , FAD.DetailsLastUpdated
      , LastViewed
      , SoftDeleted
      , SoftDeletePending
      , MoveRequired
      , HardDeletePending
    FROM files.FileDetail as FD
    INNER JOIN [files].[vw_DuplicateCounts] AS Dups ON FD.FileSize = Dups.FileSize AND FD.Height = Dups.Height AND FD.Width = Dups.Width
    INNER JOIN [files].[FileAccessDetail] as FAD ON FAD.Id = FD.FileAccessDetailId
    WHERE HardDeleted = 0;
go

